<?php
// Plugin Name: Stripe Payment
// Description: Here You Can Add Payment GateWay Using Stripe 

// access form data 
add_action('admin_post_submit', 'handle_form_data');
add_action('admin_post_nopriv_submit', 'handle_form_data');

define('plugin_path', plugin_dir_path(__FILE__));

function handle_form_data()
{
    require_once plugin_path . 'vendor/autoload.php';
    Stripe\Stripe::setApiKey('sk_test_51QVvYIGMFA43a0oW1RXr26nSFZOqlDRACbLhzo2W5RlTarukHQg1hFFRvBLjR4s2wCspZdaEDSVG6zB89wfoZNzg00Fxa61Ivy');
    $customer = Stripe\Customer::create(array(
        "address" => [
            "line1" => "Yamuna nager",
            "postal_code" => "135133",
            "city" => "yamuna nager",
            "state" => "Haryana",
            "country" => "IN",
        ],
        "email" => "gautamcoe015@gmail.com",
        "name" => "Gautam Arya",
        "source" =>  $_POST['stripeToken']
    ));



    Stripe\Charge::create([
        "amount" => 100 * 100,
        "currency" => "usd",
        "customer" => $customer->id,
        "description" => "Gautam Descripion",
        "shipping" => [
            "name" => "gautam",
            "address" => [
                "postal_code" => "135133",
                "city" => "Yamuna nager",
                "state" => "Haryana",
                "country" => "INDIA",
            ],

        ]
    ]);
    session_start();
    $_SESSION['success'] = "Successfull Payment";
    $_SESSION['num'] = "1";

    $location = $_SERVER['HTTP_REFERER'];
    wp_safe_redirect($location);
}

add_shortcode('stripe_payment_form', 'stripe_payment_form_func');
function stripe_payment_form_func()
{
    ob_start();
    session_start();
    if (isset($_SESSION['success']) && $_SESSION['num'] == 1) {
        echo "<p class='alert alert-success'>" . $_SESSION['success'] . "</p>";
        $_SESSION['num'] = 2;
    }
?>
    <!DOCTYPE html>
    <html>

    <head>
        <title>Laravel - Stripe Payment Gateway Integration Example - ItSolutionStuff.com</title>
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/3.3.7/css/bootstrap.min.css" />
        <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    </head>

    <body>
        <div class="container">
            <div class="row">
                <div class="col-md-6 col-md-offset-3">
                    <div class="panel panel-default credit-card-box">
                        <div class="panel-heading display-table">
                            <h3 class="panel-title">Payment Details</h3>
                        </div>
                        <div class="panel-body">
                            <form
                                role="form"
                                action="<?php echo admin_url('admin-post.php') ?>"
                                method="post"
                                class="require-validation"
                                data-cc-on-file="false"
                                data-stripe-publishable-key="pk_test_51QVvYIGMFA43a0oW5hvOY9qS0pDl4DhLLIc1vMQpqrlLisLcIYkpc6zhH0Pxidts0YMGmeZrNAUcx5xStTAWzDD100piUVmgr1"
                                id="payment-form">
                                <div class='form-row row'>
                                    <div class='col-xs-12 form-group required'>
                                        <label class='control-label'>Name on Card</label> <input
                                            class='form-control' value="g" size='4' type='text'>
                                    </div>
                                </div>
                                <div class='form-row row'>
                                    <div class='col-xs-12 form-group card required'>
                                        <label class='control-label'>Card Number</label> <input
                                            autocomplete='off' value="4242 4242 4242 4242" class='form-control card-number' size='20'
                                            type='text'>
                                    </div>
                                </div>
                                <div class='form-row row'>
                                    <div class='col-xs-12 col-md-4 form-group cvc required'>
                                        <label class='control-label'>CVC</label> <input autocomplete='off'
                                            class='form-control card-cvc' value="123" placeholder='ex. 311' size='4'
                                            type='text'>
                                    </div>
                                    <div class='col-xs-12 col-md-4 form-group expiration required'>
                                        <label class='control-label'>Expiration Month</label> <input
                                            class='form-control card-expiry-month' value="12" placeholder='MM' size='2'
                                            type='text'>
                                    </div>
                                    <div class='col-xs-12 col-md-4 form-group expiration required'>
                                        <label class='control-label'>Expiration Year</label> <input
                                            class='form-control card-expiry-year' value="2026" placeholder='YYYY' size='4'
                                            type='text'>
                                    </div>
                                </div>
                                <div class='form-row row'>
                                    <div class='col-md-12 error form-group hide'>

                                        <div class='alert-danger alert'>Please correct the errors and try

                                            again.</div>

                                    </div>

                                </div>



                                <div class="row">

                                    <div class="col-xs-12">
                                        <input type="text" name="action" hidden value="submit">
                                        <button class="btn btn-primary btn-lg btn-block" type="submit">Pay Now ($100)</button>

                                    </div>

                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </body>
    <script type="text/javascript" src="https://js.stripe.com/v2/"></script>
    <script type="text/javascript">
        $(function() {
            var $form = $(".require-validation");
            $('form.require-validation').bind('submit', function(e) {
                var $form = $(".require-validation"),
                    inputSelector = ['input[type=email]', 'input[type=password]',
                        'input[type=text]', 'input[type=file]',
                        'textarea'
                    ].join(', '),
                    $inputs = $form.find('.required').find(inputSelector),
                    $errorMessage = $form.find('div.error'),
                    valid = true;
                $errorMessage.addClass('hide');
                $('.has-error').removeClass('has-error');
                $inputs.each(function(i, el) {
                    var $input = $(el);
                    if ($input.val() === '') {
                        $input.parent().addClass('has-error');
                        $errorMessage.removeClass('hide');
                        e.preventDefault();
                    }
                });
                if (!$form.data('cc-on-file')) {
                    e.preventDefault();
                    Stripe.setPublishableKey($form.data('stripe-publishable-key'));
                    Stripe.createToken({
                        number: $('.card-number').val(),
                        cvc: $('.card-cvc').val(),
                        exp_month: $('.card-expiry-month').val(),
                        exp_year: $('.card-expiry-year').val()
                    }, stripeResponseHandler);
                }
            });

            function stripeResponseHandler(status, response) {
                if (response.error) {
                    $('.error')
                        .removeClass('hide')
                        .find('.alert')
                        .text(response.error.message);
                } else {
                    var token = response['id'];
                    $form.find('input[type=text]').empty();
                    $form.append("<input type='hidden' name='stripeToken' value='" + token + "'/>");
                    $form.get(0).submit();
                }
            }
        });
    </script>

    </html>
<?php
    return ob_get_clean();
}
